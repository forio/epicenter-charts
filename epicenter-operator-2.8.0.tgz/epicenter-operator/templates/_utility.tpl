{{/* vim: set filetype=mustache: */}}
{{/*
Renders a value that contains template.
Usage:
{{ include "utility.render" (dict "value" .Values.path.to.the.Value "context" $) }}
*/}}
{{- define "utility.render" -}}
    {{- if typeIs "string" .value }}
        {{- tpl .value .context }}
    {{- else }}
        {{- tpl (.value | toYaml) .context }}
    {{- end }}
{{- end -}}

{{/*
Renders a list of strings into a stringified json array of strings.
Usage:
{{ include "commaSeparatedQuotedList" .Values.path.to.the.Value }}
*/}}
{{- define "utility.commaSeparatedQuotedList" -}}
{{- $stuff := list }}
{{- range . }}
{{- $stuff = append $stuff ( . | quote ) }}
{{- end }}
{{- join "," $stuff }}
{{- end }}

